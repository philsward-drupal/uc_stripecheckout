/**
 * @file
 * uc_stripecheckout.js
 *
 * Stripe Checkout redirection
 */
(function ($) {
  Drupal.behaviors.uc_stripecheckout = {
    attach: function (context) {
      // The .once() function prevents uc_stripecheckout from reloading.
      $('#uc-cart-checkout-review-form', context).once('uc_stripecheckout', function(){
        if (Drupal.settings && Drupal.settings.uc_stripecheckout ) {
          var publishable_key = Drupal.settings.uc_stripecheckout.publishable_key;
          var checkout_session_id = Drupal.settings.uc_stripecheckout.checkout_session_id;
          var stripe = Stripe(publishable_key);
          // Setup event handler to redirect on submit
          $('#edit-submit').click(function (e) {
            // Disable the button to prevent further clicks
            $('#edit-submit').prop('disabled', false);
            // Redirect
            stripe.redirectToCheckout({
              sessionId: checkout_session_id,
            })
            .then(handleResult);
          });
          // Handle any errors returned from Checkout
          var handleResult = function (result) {
            if (result.error) {
              var displayError = document.getElementById("error-message");
              displayError.textContent = result.error.message;
            }
          };
        }
        else {
          // @todo improve error message
          alert('uc_stripecheckout settings problem');
          return;
        }
      });
    },
  };

}(jQuery));
